package com.mybatis3;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.example.dao.Test1Dao;
import com.example.entity.TechCmpCdEntity;
import com.example.entity.Test1Entity;
import com.example.entity.Test1Filter;
import com.example.entity.Test1Filter.Criteria;
import com.example.entity.Test1Key;

public class mybatisTest {

	public static void main(String[] args) throws IOException {

		/*
		 * MyBatis アプリケーションは、SqlSessionFactory のインスタンスを中心に構成されています。
		 * SqlSessionFactory のインスタンスは、SqlSessionFactoryBuilder を使って取得することができます。
		 * SqlSessionFactoryBuilder が SqlSessionFactory を生成する際の設定は、XML
		 * 形式の設定ファイルを読み込む mybatis-config.xml読み込み、SqlSessionFactoryを生成
		 * SqlSessionFactoryBuilderを使い、SqlSessionFactoryを生成
		 * SqlSesionインスタンスからSQL実行ができる。
		 */
		InputStream inputStrema = Resources
				.getResourceAsStream("mybatis-config.xml");// resources直下
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder()
				.build(inputStrema);
		SqlSession sqlSession = sqlSessionFactory.openSession();

		// Dao実行
		//insert(sqlSession);
		selectTechCmpCdList2(sqlSession);

		sqlSession.commit();
		sqlSession.close();
	}

	/*
	 * insert
	 */
	private static void insert(SqlSession sqlSession) {
		Test1Dao dao = sqlSession.getMapper(Test1Dao.class);
		Test1Entity entity = new Test1Entity();
		entity.setCol1("zuban4");
		entity.setCol2("gikyouA");
		entity.setCol3("Top1");
		entity.setCol4("work");
		entity.setCol5(new Long(1));// 排他
		int resultRow = dao.insert(entity);
	}

	/*
	 * insertSelective
	 */
	private static void insertSelective(SqlSession sqlSession) {
		Test1Dao dao = sqlSession.getMapper(Test1Dao.class);
		Test1Entity entity = new Test1Entity();
		entity.setCol1("zuban1");
		entity.setCol2("gikyouC");
		entity.setCol3("Top1");
		entity.setCol4("master");
		entity.setCol5(new Long(1));// 排他
		int resultRow = dao.insertSelective(entity);
	}

	/*
	 * selectByPrimaryKey
	 */
	private static void selectByPrimaryKey(SqlSession sqlSession) {
		Test1Dao dao = sqlSession.getMapper(Test1Dao.class);
		Test1Key key = new Test1Key();
		key.setCol1("zuban1");
		key.setCol2("gikyouA");
		Test1Entity entity = dao.selectByPrimaryKey(key);
		System.out.println(entity.getCol1());
		System.out.println(entity.getCol2());
	}

	/*
	 * selectTechCmpCdList 拡張sql
	 * parameterがシンプルで、mapper.xmlもシンプル
	 */
	private static void selectTechCmpCdList(SqlSession sqlSession) {
		Test1Dao dao = sqlSession.getMapper(Test1Dao.class);
		List<TechCmpCdEntity> list = dao.selectTechCmpCdList("master");
		for (TechCmpCdEntity entity : list) {
			System.out.println(entity.getCol1());
		}
	}

	/*
	 * selectTechCmpCdList2 拡張sql
	 * パラメータにfilterを使う
	 * mapper.xmlにfilterから設定された条件で追加しないといけないので面倒
	 */
	private static void selectTechCmpCdList2(SqlSession sqlSession) {
		Test1Dao dao = sqlSession.getMapper(Test1Dao.class);
		Test1Filter filter = new Test1Filter();
		filter.setOrderByClause("col4");
		filter.setDistinct(true);
		Criteria cr = filter.createCriteria();
		cr.andCol4EqualTo("master");
		List<TechCmpCdEntity> list = dao.selectTechCmpCdList2(filter);
		for (TechCmpCdEntity entity : list) {
			System.out.println(entity.getCol1());
		}
	}

}
