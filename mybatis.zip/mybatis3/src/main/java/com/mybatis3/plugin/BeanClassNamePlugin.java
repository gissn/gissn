package com.mybatis3.plugin;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;

/**
 * MyBatis Generatorで生成するクラス名を変更するプラグイン。
 */
public class BeanClassNamePlugin extends PluginAdapter {

    public boolean validate(List<String> warnings) {
        return true;
    }

    @Override
    public void initialized(IntrospectedTable table) {
        super.initialized(table);

        table.setBaseRecordType(table.getBaseRecordType() + "Entity");
        table.setExampleType(replace(table.getExampleType(), "Example", "Filter") );
    }

 private String replace(String target, String search, String replace) {
  Pattern pattern = Pattern.compile(search);
  Matcher matcher = pattern.matcher(target);
  target = matcher.replaceAll(replace);
  return target;
 }
}