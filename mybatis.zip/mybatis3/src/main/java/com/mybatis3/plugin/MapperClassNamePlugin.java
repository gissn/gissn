package com.mybatis3.plugin;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;
public class MapperClassNamePlugin extends PluginAdapter {
 public boolean validate(List<String> warnings) {
  return true;
 }
 @Override
 public void initialized(IntrospectedTable introspectedTable) {
  introspectedTable.setMyBatis3JavaMapperType(replace(introspectedTable.getMyBatis3JavaMapperType(), "Mapper", "Dao"));//~Mapper.java を変更
  introspectedTable.setMyBatis3XmlMapperFileName(replace(introspectedTable.getMyBatis3XmlMapperFileName(), "Mapper", "Dao")); //~Mapper.xml を変更
 }
 private String replace(String target, String search, String replace) {
  Pattern pattern = Pattern.compile(search);
  Matcher matcher = pattern.matcher(target);
  target = matcher.replaceAll(replace);
  return target;
 }
}