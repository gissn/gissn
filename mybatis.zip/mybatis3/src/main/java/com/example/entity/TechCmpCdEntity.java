package com.example.entity;

public class TechCmpCdEntity {

	private String col1;

    public String getCol1() {
        return col1;
    }

    public void setCol1(String col1) {
        this.col1 = col1;
    }


}